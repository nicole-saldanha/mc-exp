package com.example.mybluetoothapplication

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mStatusBlueTv = findViewById<TextView>(R.id.statusBluetoothTv)
        val mPairedTv = findViewById<TextView>(R.id.pairedTv)
        val mBlueIv = findViewById<ImageView>(R.id.bluetoothIv)
        val mOnBtn = findViewById<Button>(R.id.onBtn)
        val mOffBtn = findViewById<Button>(R.id.offBtn)
        val mDiscoverBtn = findViewById<Button>(R.id.discoverableBtn)
        val mPairedBtn = findViewById<Button>(R.id.pairedBtn)

        val bluetoothManager: BluetoothManager =
            getSystemService(BluetoothManager::class.java)
        val mBlueAdapter: BluetoothAdapter? = bluetoothManager.adapter

        val permit = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            if (permissions[Manifest.permission.BLUETOOTH] == false ||
                permissions[Manifest.permission.BLUETOOTH_SCAN] == false ||
                permissions[Manifest.permission.BLUETOOTH_ADMIN] == false ||
                permissions[Manifest.permission.BLUETOOTH_CONNECT] == false ||
                permissions[Manifest.permission.BLUETOOTH_ADVERTISE] == false ||
                permissions[Manifest.permission.BLUETOOTH_PRIVILEGED] == false
            ) {
                showToast("Couldn't turn on Bluetooth")
            }
        }

        if (mBlueAdapter == null) {
            mStatusBlueTv.text = "Bluetooth is not supported"
        } else {
            mStatusBlueTv.text = "Bluetooth is available"
        }

        mBlueIv.setImageResource(if (mBlueAdapter?.isEnabled == true) R.drawable.ic_action_on else R.drawable.ic_action_off)

        mOnBtn.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    permit.launch(arrayOf(Manifest.permission.BLUETOOTH))
                }
                return@setOnClickListener
            }
            if (mBlueAdapter != null) {
                if (!mBlueAdapter.isEnabled) {
                    showToast("Turning On Bluetooth...")
                } else {
                    showToast("Bluetooth is already on")
                }
            }
        }

        mDiscoverBtn.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_SCAN
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    permit.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN))
                }
                return@setOnClickListener
            }
            if (mBlueAdapter != null) {
                if (!mBlueAdapter.isDiscovering) {
                    showToast("Making Your Device Discoverable")
                    val intent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    startActivityForResult(intent, REQUEST_DISCOVER_BT)
                }
            }
        }

        mOffBtn.setOnClickListener {
            if (mBlueAdapter != null) {
                if (mBlueAdapter.isEnabled) {
                    mBlueAdapter.disable()
                    showToast("Turning Bluetooth Off")
                    mBlueIv.setImageResource(R.drawable.ic_action_off)
                } else {
                    showToast("Bluetooth is already off")
                }
            }
        }

        mPairedBtn.setOnClickListener {
            if (mBlueAdapter != null) {
                if (mBlueAdapter.isEnabled) {
                    mPairedTv.text = "Paired Devices"
                    val devices: Set<BluetoothDevice> = mBlueAdapter.bondedDevices
                    for (device in devices) {
                        mPairedTv.append("Device: ${device.name}, $device\n")
                    }
                } else {
                    showToast("Turn on bluetooth to get paired devices")
                }
            }
        }
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val REQUEST_DISCOVER_BT = 1
    }
}
